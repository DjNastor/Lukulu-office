# Lukulu HQ v33 Final Install
Phone: Open in Chrome -> Menu -> Add to Home Screen -> Install
Windows: Download EXE -> Run installer -> Launch
macOS: Download DMG -> Drag to Applications -> Right-click Open
Android APK: Download APK -> Allow unknown sources -> Install
PWA: Install button gold pulse