# Lukulu HQ v32 - Installation Guide

## Quick Install (All Devices)
- **Windows**: Download EXE -> Run -> Next -> Launch from Desktop
- **macOS**: Download DMG -> Drag to Applications -> Right-click Open
- **Android APK**: Download APK -> Allow Unknown Sources -> Install
- **Android PWA**: Chrome Menu -> Add to Home Screen -> Install (Recommended 2MB)
- **iOS**: Safari Share -> Add to Home Screen
- **PWA**: Chrome address bar Install icon -> Install

## System Requirements
| Platform | OS | RAM | Storage | Browser |
|----------|----|-----|---------|---------|
| Windows | 10/11 64-bit | 4GB | 200MB | Chrome/Edge/Electron |
| macOS | 11+ Big Sur | 4GB | 200MB | Safari/Chrome |
| Android | 8+ | 2GB | 100MB | Chrome |
| iOS | 14+ | 2GB | 100MB | Safari |
| Linux | Ubuntu 20.04+ | 2GB | 200MB | Chrome/Firefox |
| PWA | Any | 1GB | 50MB | Modern |

## Troubleshooting
- Windows SmartScreen: More Info -> Run Anyway
- macOS Gatekeeper: Right-click -> Open, or xattr -cr /Applications/Lukulu\ HQ.app
- Android Unknown Sources: Settings -> Security -> Allow Unknown Sources
- PWA not installing: Use Chrome/Edge latest, clear cache, check HTTPS

## WhatsApp Channel
https://whatsapp.com/channel/0029VbECoXDJUM2i3Dz9Tu3D

## Version History
- v28 Global, v29 Sync Publishing, v30 Contracts, v31 Easy Command Voice, v32 Global Install
