# Windows Install
1. Download EXE
2. Run installer
3. Launch from desktop
4. Login with Meta App 1098856779428013
