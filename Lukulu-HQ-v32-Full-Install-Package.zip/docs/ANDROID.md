# Android Install
Option A APK
1. Download APK
2. Allow unknown sources
3. Install
Option B PWA (Recommended)
1. Chrome Menu -> Add to Home Screen
2. Install
