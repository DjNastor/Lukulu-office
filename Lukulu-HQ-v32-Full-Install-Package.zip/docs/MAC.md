# macOS Install
1. Download DMG
2. Drag to Applications
3. Right-click Open
4. Allow notifications
