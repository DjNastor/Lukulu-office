# PWA Install
Chrome/Edge: Install icon in address bar
Firefox: Menu -> Install
Safari Mac: File -> Add to Dock
Safari iOS: Share -> Add to Home Screen
