# Lukulu HQ v32 - Build Instructions

## Windows PC - EXE Installer
1. Install Node.js 20+ from https://nodejs.org
2. npm install -g electron-builder
3. npm install
4. npm run build-win
5. Output: dist/Lukulu HQ Setup 32.0.0.exe (~85MB)

## macOS - DMG + APP
1. Install Node.js 20+
2. npm install
3. npm run build-mac
4. Output: dist/Lukulu HQ-32.0.0.dmg (~92MB) Universal Intel + Apple Silicon
5. For unsigned: xattr -cr /Applications/Lukulu\ HQ.app

## Android - APK via PWABuilder
1. Host PWA at https://lukulu-recordings.com
2. Go to https://www.pwabuilder.com
3. Enter URL, Package for Android
4. Download APK (~18MB) + AAB
5. Or direct PWA: Chrome -> Add to Home Screen (2MB)

## PWA - Universal
1. Ensure manifest.json + service-worker.js in root
2. HTTPS required
3. Chrome DevTools > Application > Manifest check
4. Lighthouse PWA score 100

## Linux
chmod +x Lukulu-HQ-v32.AppImage
./Lukulu-HQ-v32.AppImage

Version: 32.0.0
Contacts: 4709 (Radio 157 + Curators 49 + Promoters 5 + Promoly 4427 + InStore 18 + Other 10 + Sync 20 + Publishing 8 + Other 15)


## Android Specific
- Offline PWA + TWA wrapper
- Push notifications
- Background sync
