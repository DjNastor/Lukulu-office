const CACHE = 'lukulu-hq-v32-global-install';
const ASSETS = ['./','./index.html','./manifest.json','./lukulu-real-icon-192.png','./lukulu-real-icon-512.png'];
self.addEventListener('install', (event)=>{
  event.waitUntil(caches.open(CACHE).then(cache=>cache.addAll(ASSETS)).then(()=>self.skipWaiting()));
});
self.addEventListener('activate', (event)=>{
  event.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k!==CACHE).map(k=>caches.delete(k)))).then(()=>self.clients.claim()));
});
self.addEventListener('fetch', (event)=>{
  if(event.request.method!=='GET') return;
  event.respondWith(
    caches.match(event.request).then(cached=>{
      const fetchPromise = fetch(event.request).then(network=>{
        if(network && network.status===200 && network.type==='basic'){
          const clone = network.clone();
          caches.open(CACHE).then(cache=>cache.put(event.request, clone));
        }
        return network;
      }).catch(()=>cached);
      return cached || fetchPromise;
    })
  );
});
self.addEventListener('message', (e)=>{ if(e.data==='SKIP_WAITING') self.skipWaiting(); });
