# Lukulu HQ v11 PWA - APK Ready Package with Real Logos

This package contains your real Lukulu branding icons ready for Play Store / App Store submission.

## Contents:

### Real Logos (Source):
- L Gold Logo: Black bg #050507 gold border #d4af37 gold L dot — your main app icon
- Africa Lukulu Logo: Black bg white Africa pattern with speaker + hand + Lukulu script — splash/secondary

### Icons Generated:
- icon-L-48x48.png through icon-L-1024x1024.png — Main app icons (L gold)
- icon-L-maskable-48x48.png through icon-L-maskable-1024x1024.png — Maskable icons with 20% padding safe zone (required for Android adaptive icons)
- icon-Africa-192x192.png, 512x512.png, 1024x1024.png — Africa Lukulu alternative
- favicon-16x16.png, favicon-32x32.png
- manifest.json — PWA manifest with all icons

## How to Build APK:

### Option 1: PWABuilder.com (EASIEST - No Code):
1. Go to https://www.pwabuilder.com
2. Enter your PWA URL: [Your Lukulu HQ v11 artifact URL]
3. Click Start → Package for Stores
4. Select Android → Generate Package
5. Upload icon-L-512x512.png as store icon when prompted
6. Download .aab file (Android App Bundle) ready for Play Store
7. For iOS: Select iOS package too

### Option 2: Bubblewrap (Google's Official TWA Tool):
```bash
npm i -g @bubblewrap/cli
bubblewrap init --manifest https://your-pwa-url/manifest.json
bubblewrap build
```
This generates APK + AAB using Trusted Web Activity.

### Option 3: Android Studio (Manual TWA):
1. Create new project with "Add Trusted Web Activity"
2. Use manifest.json from this package
3. Set theme #050507 / #d4af37
4. Build signed APK/AAB

## Play Store Submission Requirements:
- App Icon: icon-L-512x512.png (512x512, 32-bit PNG)
- Feature Graphic: 1024x500 (create from L logo + Africa logo)
- Screenshots: Phone + Tablet
- Short Description: "Radio 145 + Promoly 4427 + 39 Curators + 164 Tracks + Drive 13 + Yangaroo — Full Automation HQ for Lukulu Recordings"
- Package Name suggestion: com.lukulurecordings.hq
- Theme: Black #050507 Gold #d4af37

## App Store (iOS) Submission:
- App Icon: icon-L-1024x1024.png (1024x1024, no transparency, no alpha channel — flatten to #050507)
- Use PWABuilder iOS package or convert PWA to native wrapper with Cordova/Capacitor

## Manifest Details:
- Name: Lukulu Recordings - Full Automation HQ
- Short: Lukulu HQ
- Display: standalone (no browser bar)
- Background: #050507
- Theme: #d4af37 gold
- Start URL: .
- Categories: music, business, productivity

## Real Logos Integration:
- L Gold Logo used for: favicon, apple-touch-icon, PWA icons 48-1024, maskable icons, header 48x48, footer 120x120, splash
- Africa Logo used for: secondary branding header 60x60, footer 200x200, splash background, alternative icon

All icons have solid #050507 background (required for Play Store — no transparency).

Generated: Lukulu HQ v11 PWA Final with Real Logos
Johannesburg, South Africa
